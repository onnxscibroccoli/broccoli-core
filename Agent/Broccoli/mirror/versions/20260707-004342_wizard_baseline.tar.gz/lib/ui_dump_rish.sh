#!/data/data/com.termux/files/usr/bin/bash
set -eu
GROK_PKG=ai.x.grok
DEV=/data/local/tmp/broccoli_ui.xml
OUT="$HOME/broccoli/ui/last_ui.xml"
LOG="$HOME/broccoli/reports/dump.log"
log(){ echo "$(date -Iseconds) $*" >> "$LOG"; }
bash "$HOME/broccoli/lib/fg_grok_only.sh" >>"$LOG" 2>&1 || true
for i in $(seq 1 16); do
  bash "$HOME/broccoli/lib/adb_rish.sh" "uiautomator dump --compressed $DEV" >/dev/null 2>&1 || true
  bash "$HOME/broccoli/lib/adb_rish.sh" "cat $DEV" > "$OUT.tmp" 2>/dev/null || true
  [ -s "$OUT.tmp" ] && grep -q "<hierarchy" "$OUT.tmp" || { sleep 0.25; continue; }
  HG=$(grep -c "package=\"$GROK_PKG\"" "$OUT.tmp" 2>/dev/null || echo 0)
  HT=$(grep -c "package=\"com.termux\"" "$OUT.tmp" 2>/dev/null || echo 0)
  if [ "$HG" -gt 0 ] && [ "$HT" -eq 0 ]; then
    mv -f "$OUT.tmp" "$OUT"
    log "ok bytes=$(wc -c < "$OUT") try=$i"
    wc -c < "$OUT"
    exit 0
  fi
  bash "$HOME/broccoli/lib/launch_grok_native.sh" >/dev/null 2>&1 || true
  sleep 0.35
done
rm -f "$OUT.tmp"
log "FAIL"
echo 0
exit 1
