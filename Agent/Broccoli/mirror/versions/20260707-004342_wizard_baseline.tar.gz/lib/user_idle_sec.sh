#!/data/data/com.termux/files/usr/bin/bash
# Seconds since last user interaction (best-effort via dumpsys).
set -eu
RAW="$(bash "$HOME/broccoli/lib/adb_rish.sh" "dumpsys input" 2>/dev/null || true)"
# Last line with time since last event (device-dependent)
SEC="$(printf '%s\n' "$RAW" | grep -iE 'Last.*Time|time since last|lastUserActivity' | tail -1 | grep -oE '[0-9]+' | head -1)"
[ -n "$SEC" ] && { echo "$SEC"; exit 0; }
# Fallback: unchanged UI hash for ~3 polls => treat as 3 idle
HASH="$(md5sum "$HOME/broccoli/ui/last_ui.xml" 2>/dev/null | awk '{print $1}')"
STAMP="$HOME/broccoli/meta/idle_hash.ts"
LAST="$HOME/broccoli/meta/idle_hash.last"
NOW=$(date +%s)
echo "$HASH" > "$HOME/broccoli/meta/idle_hash.cur"
if [ -f "$LAST" ] && [ "$(cat "$LAST")" = "$HASH" ] && [ -f "$STAMP" ]; then
  echo $(( NOW - $(cat "$STAMP") ))
else
  echo "$HASH" > "$LAST"
  echo "$NOW" > "$STAMP"
  echo 0
fi
