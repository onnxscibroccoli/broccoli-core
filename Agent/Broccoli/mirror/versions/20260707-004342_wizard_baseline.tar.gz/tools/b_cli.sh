#!/data/data/com.termux/files/usr/bin/bash
export PATH="$HOME/bin:$PATH:/data/data/com.termux/files/usr/bin"
exec bash "$HOME/broccoli/tools/b_cli.sh" "$@"
