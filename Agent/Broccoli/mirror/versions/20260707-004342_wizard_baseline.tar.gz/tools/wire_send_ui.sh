#!/data/data/com.termux/files/usr/bin/bash
set -eu
export PATH="$HOME/bin:$PATH:/data/data/com.termux/files/usr/bin"
MSG="$(bash "$HOME/broccoli/tools/safe_wire_message.sh" "$1")"
LOG="$HOME/broccoli/reports/wire_send.log"
LOCK="$HOME/broccoli/meta/wire_inflight"
[ -n "$MSG" ] || exit 2
log(){ echo "$(date -Iseconds) $*" | tee -a "$LOG"; }
rish(){ bash "$HOME/broccoli/lib/adb_rish.sh" "$@"; }

if [ -f "$LOCK" ]; then
  read -r LH LT < "$LOCK" 2>/dev/null || true
  NOW=$(date +%s)
  if [ "${LH:-}" = "$MSG" ] && [ $((NOW - ${LT:-0})) -lt 90 ]; then
    log "SKIP dup inflight"
    exit 0
  fi
fi
printf '%s %s\n' "$MSG" "$(date +%s)" > "$LOCK"

log "SEND len=${#MSG}"
date +%s > "$HOME/broccoli/meta/last_wire_activity" 2>/dev/null || true
FP0="$(python3 "$HOME/broccoli/tools/phrase_grok_dump.py" fp 2>/dev/null || echo 0)"
bash "$HOME/broccoli/lib/ui_dump_rish.sh" >/dev/null 2>&1 || { log "dump fail"; rm -f "$LOCK"; exit 2; }
grep -q 'package="ai.x.grok"' "$HOME/broccoli/ui/last_ui.xml" || { log "not grok fg"; rm -f "$LOCK"; exit 2; }

bash "$HOME/broccoli/tools/dump_send_row.sh" >>"$LOG" 2>&1 || true

python3 -c "
import re,subprocess
from pathlib import Path
x=Path.home().joinpath('broccoli/ui/last_ui.xml').read_text(errors='replace')
m=re.search(r'chat_text_input[^>]*bounds=\"\[(\d+),(\d+)\]\[(\d+),(\d+)\]\"',x) or re.search(r'EditText[^>]*bounds=\"\[(\d+),(\d+)\]\[(\d+),(\d+)\]\"',x)
if m:
 a,b,c,d=map(int,m.groups())
 subprocess.run(['bash','-c',f'printf \"input tap {(a+c)//2} {(b+d)//2}\\n\" | rish'],check=False)
" 2>/dev/null || true
sleep 0.15
termux-clipboard-set <<< "$MSG"
rish "input keyevent 279" >/dev/null 2>&1 || true
sleep 0.2

FRAG="$(printf '%s' "$MSG" | head -c 22)"
SENT=0
for n in 1 2 3 4 5; do
  log "send_enter try=$n"
  rish "input keyevent 66" >/dev/null 2>&1 || true
  sleep 0.45
  bash "$HOME/broccoli/lib/ui_dump_rish.sh" >/dev/null 2>&1 || true
  if grep -qF "$FRAG" "$HOME/broccoli/ui/last_ui.xml" 2>/dev/null; then
    SENT=1
    log "send_ok"
    break
  fi
  if [ "$n" -ge 3 ]; then
    python3 "$HOME/broccoli/tools/find_send_tap.py" >>"$LOG" 2>&1 || true
    sleep 0.45
    bash "$HOME/broccoli/lib/ui_dump_rish.sh" >/dev/null 2>&1 || true
    grep -qF "$FRAG" "$HOME/broccoli/ui/last_ui.xml" 2>/dev/null && SENT=1 && log "send_ok_tap" && break
  fi
done
[ "$SENT" -eq 1 ] || log "send_unconfirmed"

for t in $(seq 1 40); do
  bash "$HOME/broccoli/lib/ui_dump_rish.sh" >/dev/null 2>&1 || true
  REPLY="$(python3 "$HOME/broccoli/tools/phrase_grok_dump.py" last "$MSG" 2>/dev/null || true)"
  FP="$(python3 "$HOME/broccoli/tools/phrase_grok_dump.py" fp 2>/dev/null || true)"
  if [ -n "$REPLY" ] && [ "$REPLY" != "$MSG" ]; then
    log "phrased=$REPLY"
    echo "$REPLY" >> "$HOME/broccoli/thread/grok_last.txt"
    rm -f "$LOCK"
    echo "$REPLY" >> "$HOME/broccoli/thread/grok_last.txt"
    exit 0
  fi
  if [ "$SENT" -eq 1 ] && [ -n "$FP" ] && [ "$FP" != "$FP0" ]; then
    REPLY="$(python3 "$HOME/broccoli/tools/phrase_grok_dump.py" last "$MSG" 2>/dev/null || true)"
    [ -n "$REPLY" ] && [ "$REPLY" != "$MSG" ] && { log "phrased_fp=$REPLY"; rm -f "$LOCK"; echo "$REPLY"; exit 0; }
  fi
  sleep 0.3
done
log "receive_timeout"
rm -f "$LOCK"
exit 1

# BROCCOLI_ENTER_V2 — if taps miss send, force ENTER after paste
if [ -z "${REPLY:-}" ] || [ "${REPLY:-}" = "TIMEOUT" ]; then
  input keyevent 66 2>/dev/null || true
  sleep 2
fi
