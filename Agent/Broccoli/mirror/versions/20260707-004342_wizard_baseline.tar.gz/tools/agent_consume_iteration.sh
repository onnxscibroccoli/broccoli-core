#!/data/data/com.termux/files/usr/bin/bash
# Turn last phrased chat reply into next automatic iteration.
set -eu
export PATH="$HOME/bin:$PATH:/data/data/com.termux/files/usr/bin"
LOG="$HOME/broccoli/reports/agent_consume.log"
PROMPT="${1:-}"
REPLY="${2:-}"

[ -n "$REPLY" ] || REPLY="$(tail -1 "$HOME/broccoli/thread/grok_last.txt" 2>/dev/null || true)"
[ -n "$PROMPT" ] || PROMPT="$(python3 -c "import json;print(json.load(open('$HOME/broccoli/meta/agent_iteration.json')).get('last_prompt',''))" 2>/dev/null || true)"

echo "$(date -Iseconds) consume prompt_len=${#PROMPT} reply_len=${#REPLY}" >> "$LOG"

ACTION="$(python3 "$HOME/broccoli/tools/reply_to_next_action.py" "$REPLY" "$PROMPT" 2>>"$LOG" | head -1)"
echo "$(date -Iseconds) action=$ACTION" >> "$LOG"

case "${ACTION%%|*}" in
  APPLY)
    bash "$HOME/broccoli/tools/agent_apply_reply.sh" >>"$LOG" 2>&1 || true
    # After apply, queue a verify wire
    printf '%s\n' 'ASK|Reply one word: APPLY_OK' >> "$HOME/broccoli/queue/pending.txt"
    ;;
  QUEUE)
    PAYLOAD="${ACTION#QUEUE|}"
    printf '%s\n' "ASK|$PAYLOAD" > "$HOME/broccoli/queue/pending.txt"
    ;;
  DONE)
    echo "$(date -Iseconds) mission_done" >> "$LOG"
    python3 -c "import json;d=json.load(open('$HOME/broccoli/meta/agent_iteration.json'));d['status']='done';json.dump(d,open('$HOME/broccoli/meta/agent_iteration.json','w'),indent=2)"
    ;;
  WAIT)
    ;;
  FAIL|*)
    printf '%s\n' 'ASK|Broccoli: reply one word STATUS' > "$HOME/broccoli/queue/pending.txt"
    ;;
esac

# Persist prompt for next consume
python3 <<PY
import json
from pathlib import Path
p=Path.home()/"broccoli/meta/agent_iteration.json"
d=json.loads(p.read_text()) if p.is_file() else {}
d["last_prompt"]="""${PROMPT}"""
d["last_reply"]="""${REPLY}"""[:2000]
p.write_text(json.dumps(d,indent=2,ensure_ascii=False))
PY
